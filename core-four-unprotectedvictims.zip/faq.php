<?php
// Metadata
$title = "UnProtected Victims";
include 'shared.php'?>
<?=$header?> <!--Header-->
</head>
<body>
<?=$nav?><!--Nav-->
<main>

<main>
<div class="hero get-help-hero">
<h1>FAQ</h1>
</div>

<div class="container">
  <div class="row justify-content-center">

    <div class="col-xs-12 col-md-10">
<button class="accordion">Consectetur adipisicing elit? <i class="fa fa-angle-down" aria-hidden="true"></i>
</button>
<div class="panel">
  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
</div>

<button class="accordion">Lorem ipsum dolor sit amet? <i class="fa fa-angle-down" aria-hidden="true"></i>
</button>
<div class="panel">
  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
</div>

<button class="accordion">Sed do eiusmod tempor incididunt ut labore? <i class="fa fa-angle-down" aria-hidden="true"></i>
</button>
<div class="panel">
  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
</div>
<button class="accordion">Sed do eiusmod tempor incididunt ut labore? <i class="fa fa-angle-down" aria-hidden="true"></i>
</button>
<div class="panel">
  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
</div>
<button class="accordion">Sed do eiusmod tempor incididunt ut labore? <i class="fa fa-angle-down" aria-hidden="true"></i>
</button>
<div class="panel">
  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
</div>
<button class="accordion">Sed do eiusmod tempor incididunt ut labore? <i class="fa fa-angle-down" aria-hidden="true"></i>
</button>
<div class="panel">
  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
</div>
</div></div></div>
<script> // Sets accordians to display if clicked
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.display === "block") {
      panel.style.display = "none";



    } else {
      panel.style.display = "block";
    }
  });
}
</script>




</main>
<?=$footer?> <!--Footer-->
  </body>
</html>
